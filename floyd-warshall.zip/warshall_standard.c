// Standard CPU implementation of Floyd-Warshall.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <math.h>

#include "warshall.h"

void warshall_standard(edge_int_t* matrix, int vertex_count)
{
	int i,j,k;
	edge_int_t* jk = matrix;
	edge_int_t* ji = matrix;
	edge_int_t* ik = matrix;
	for(i = 0; i < vertex_count; i++)
	{
		for(j = 0; j < vertex_count; j++)
		{
			for(k = 0; k < vertex_count; k++)
			{
				*jk = MIN(*jk,*ji+*ik);
				jk++;
				ik++;
			}
			ik = ik - vertex_count;
			ji += vertex_count;
		}
		ji = ji - (vertex_count)*(vertex_count) + 1;
		jk = jk - (vertex_count)*(vertex_count);
		ik += vertex_count;
	}
}




