#ifndef WARSHALL_H
#define WARSHALL_H

#include <limits.h>
#include <stdint.h>

#define MIN(X,Y) (((X)>(Y)) ? (Y) : (X))
#define MAX(X,Y) (((Y)>(X)) ? (Y) : (X))

#define TILE_SIZE_2 5
#define DBL_TILE_SIZE_2 2

#define TILE_SIZE 32
#define DBL_TILE_SIZE 4

typedef struct
{
	int c;
	int r;
}
entry_pos_t;

// Get the relative mem location of the tile at a tile-based row and col.
#define GET_TILE(row,col,tpr2) ((((row)<<(tpr2))+(col))<<(TILE_SIZE_2 << 1))
// Within a tile, get the relative mem location of the dbl-tile at a dbl-tile-based row and col
#define GET_DBL_TILE_IN_TILE(row,col) ((((row)<<(TILE_SIZE_2-DBL_TILE_SIZE_2))+(col))<<(DBL_TILE_SIZE_2 << 1))

#define NO_EDGE (INT32_MAX/2)

typedef int32_t edge_int_t;
#ifdef __cplusplus
extern "C"
{
#endif
void warshall_standard(edge_int_t* matrix, int vertex_count);
void warshall_tiled(edge_int_t* matrix, int vertex_count);
void cuda_warshall_standard(edge_int_t* matrix, int vertex_count);
void threaded_warshall_standard(edge_int_t* matrix, int vertex_count);
void cuda_warshall_tiled(edge_int_t* matrix, int vertex_count);
void cuda_warshall_dbl_tiled(edge_int_t* matrix, int vertex_count);
void cuda_katz_kider(edge_int_t* matrix, int vertex_count);
#ifdef __cplusplus
}
#endif
#endif
