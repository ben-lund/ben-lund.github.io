// Blocked implementation of Floyd-Warshall for the CPU.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <math.h>
#include <stdint.h>

#include "warshall.h"

long tileSize = 64;

void singleTileWarshall(edge_int_t* matrix, int vertex_count, int row, int col, int t)
{
	int i,j,k;
	for(i = t; i < tileSize + t; i++)
	{
		for(j = row; j < tileSize + row; j++)
		{
			for(k = col; k < tileSize + col; k++)
			{
				edge_int_t jk = *(matrix + vertex_count*j + k);
				edge_int_t ji = *(matrix + vertex_count*j + i);
				edge_int_t ik = *(matrix + vertex_count*i + k);
				*(matrix + vertex_count*j + k) = MIN(jk, ji+ik);
			}
		}
	}
}

void warshall_tiled(edge_int_t* matrix, int vertex_count)
{
	long col, row, t;
	// loop over self-dependent tile indexes
	for(t = 0; t < vertex_count; t+=tileSize)
	{

		//process the self-dependent tile
		singleTileWarshall(matrix, vertex_count, t, t, t);

		//process the singly-dependent tiles
		for(row = 0; row < vertex_count; row+= tileSize)
		{
			if(row == t) continue; // self-dependent tile already processed
			singleTileWarshall(matrix, vertex_count, row, t, t);
		}
		for(col = 0; col < vertex_count; col += tileSize)
		{
			if(col == t) continue;
			singleTileWarshall(matrix, vertex_count, t, col, t);
		}
			
		//process the doubly-dependent tiles
		for(row = 0; row < vertex_count; row += tileSize)
			for(col = 0; col < vertex_count; col += tileSize)
			{
				if(row == t || col == t) continue;
				singleTileWarshall(matrix, vertex_count, row, col, t);
			}
	}
}
