#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sched.h>
#include <semaphore.h>

#include "warshall.h"



#define checkResults(string, val) {             \
 if (val) {                                     \
   printf("Failed with %d at %s", val, string); \
   exit(1);                                     \
 }                                              \
}

#define NUM_THREADS 4

typedef struct
{
	int num;
	int start;
	int end;
} pair_t;

static edge_int_t* g_matrix;
static int g_vertex_count;

static sem_t g_master_sem;
static sem_t* g_sems;


void * warshall_thread(void* p)
{
	pair_t pair = *((pair_t*)p);
	int i, j, k, rc;

	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET( pair.num, &mask );

	rc = sched_setaffinity( getpid(), sizeof(cpu_set_t), &mask );
	checkResults("sched_setaffinity", rc);
	
	for(i = 0; i < g_vertex_count; i++)
	{
		sem_wait(&g_sems[pair.num]);

		for(j = pair.start; j < pair.end; j++)
		{
			for(k = 0; k < g_vertex_count; k++)
			{ 
				edge_int_t jk = *(g_matrix + ((g_vertex_count*j)+k));
				edge_int_t ji = *(g_matrix + ((g_vertex_count*j)+i));
				edge_int_t ik = *(g_matrix + ((g_vertex_count*i)+k));

				*(g_matrix + ((g_vertex_count*j)+k)) = MIN(jk,ji+ik);
			}
		}
		sem_post(&g_master_sem);
	}
	pthread_exit(NULL);
	return (void*)0;
}

void threaded_warshall_standard(edge_int_t* matrix, int vertex_count)
{
	int i,j,rc;
	g_matrix = matrix;
	g_vertex_count = vertex_count;

	pthread_t* threads = (pthread_t*)malloc(sizeof(pthread_t) * NUM_THREADS);
	pair_t* pairs = (pair_t*)malloc(sizeof(pair_t) * NUM_THREADS);
	g_sems = (sem_t*)malloc(sizeof(sem_t) * NUM_THREADS);
	
	rc = sem_init(&g_master_sem, 0, 0);
	checkResults("sem_init", rc);
	
	for(i = 0; i < NUM_THREADS; i++)
	{
		pairs[i].start = (i*vertex_count)/NUM_THREADS;
		pairs[i].end = ((i+1)*vertex_count)/NUM_THREADS;
		pairs[i].num = i;
		rc = sem_init(&g_sems[i], 0, 0);
		checkResults("sem_init", rc);
		rc = pthread_create(&threads[i], NULL, warshall_thread, (void*)(pairs+i));
		checkResults("pthread_create", rc);
	}

	for(i = 0; i < vertex_count; i++)
	{
		for(j = 0; j < NUM_THREADS; j++)
		{
			sem_post(&g_sems[j]);
		}
		for(j = 0; j < NUM_THREADS; j++)
		{
			sem_wait(&g_master_sem);
		}
	}

	for(j = 0; j < NUM_THREADS; j++)
	{
		pthread_join(threads[j], NULL);
		sem_destroy(&g_sems[j]);
	}
	free(g_sems);
	free(pairs);
	free(threads);
}
