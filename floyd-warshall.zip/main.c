/**
* This provides the main method for all of the various floyd-warshall implementations provided.
* It creates a random graph and runs a specified algorithm on it.
* The following command line flags are supported:
* -v - graph size, number of vertices; must be a multiple of 32
* -i - floyd-warshall implementation to use
* -t - test output for correctness (will run two algorithms against the same graph and test the output to make sure it's identical)
* -p - print the adjacency matrix before and after running the algorithm
* The following implementations are supported:
* STANDARD - CPU based implementation
* TILED - cache-efficient CPU based implementation
* CUDA_STANDARD - single thread per task decomposition
* KATZ_KIDER - blocked CUDA implementation
* CUDA_TILED - blocked CUDA implementation with some improvements to reduce time spent computing result
* CUDA_DBL_TILED - blocked CUDA implementation with improvements to reduce instruction latency
* THREADED - Floyd-Warshall implementation using PTHREADS
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <stdint.h>

#include "warshall.h"

#define DEFAULT_VERTEX_COUNT 32
#define DEFAULT_VERTEX_DEGREE 7
#define DEFAULT_MAX_EDGE_WEIGHT 3

entry_pos_t compute_dbl_tile_pos(int pos, entry_pos_t current, int vertex_count)
{
	entry_pos_t result;
	if(pos == 0)
	{
		result.r = 0;
		result.c = 0;
		return result;
	}		
	int r = current.r;
	int c = current.c;
	if((pos % DBL_TILE_SIZE) == 0)
	{
		if(pos % (DBL_TILE_SIZE*DBL_TILE_SIZE) == 0)
		{
			if(pos % (DBL_TILE_SIZE*TILE_SIZE) == 0)
			{
				if(pos % (TILE_SIZE*TILE_SIZE) == 0)
				{
					if(pos % (vertex_count*TILE_SIZE) == 0)
					{
						c = 0;
						r += 1;
					}
					else
					{
						c += 1;
						r -= (TILE_SIZE-1);
					}		
				}
				else
				{
					r += 1;
					c -= (TILE_SIZE-1);
				}
			}
			else
			{
				r -= (DBL_TILE_SIZE-1);
				c += 1;
			}		
		}
		else
		{
			r += 1;
			c -= (DBL_TILE_SIZE-1);		
		}
	}
	else
	{
		c += 1;
	}
	result.r = r;
	result.c = c;
	return result;
}

#define CHECK(num,pos,val) if(val >= vertex_count || val < 0) printf("ERROR!!! %d - pos: %ld -  next_pos: %d\n", num, pos, val)

void dbl_tile_matrix(edge_int_t* in, edge_int_t* out, int vertex_count)
{
	long pos;
/*
	entry_pos_t next_pos;
	next_pos.r = 0;
	next_pos.c = 0;*/
	
	for(pos = 0; pos < ((long)vertex_count*(long)vertex_count); pos++)
	{/*
		next_pos = compute_dbl_tile_pos(pos, next_pos, vertex_count);
		CHECK(1,pos,next_pos.r);
		CHECK(2,pos,next_pos.c);
		*(out+((next_pos.r*vertex_count)+next_pos.c)) = *(in+pos);*/
		int blNum = pos / 1024;
		int blRem = pos % 1024;
		int bRow = blNum / (vertex_count / 32);
		int bCol = blNum % (vertex_count / 32);
		int sbNum = blRem / 16;
		int sbRem = blRem % 16;
		int sRow = sbNum / 8;
		int sCol = sbNum % 8;
		int remRow = sbRem / 4;
		int remCol = sbRem % 4;
		int totalRow = bRow * 32 + sRow * 4 + remRow;
		int totalCol = bCol * 32 + sCol * 4 + remCol;
		int totalIndex = totalRow * vertex_count + totalCol;
		*(out + pos) = *(in + totalIndex);
	}
}


void populate_matrix(edge_int_t* matrix, long vertex_count, long prob, long max_distance)
{
	long i, j;
	srand(time(NULL));
	for(i = 0; i < vertex_count; i++)
	{
		for(j = 0; j < vertex_count; j++)
		{
			if(i == j)
			{
				*(matrix + ((vertex_count*i)+j)) = 0;
			}
			else if(rand()%prob != 0) // (1/prob) probability of any order pair of vertices having an edge
			{
				*(matrix + ((vertex_count*i)+j)) = NO_EDGE;
			}
			else
			{
				*(matrix + ((vertex_count*i)+j)) = rand()%max_distance+1;
			}
		}
	}
}


void display_matrix(edge_int_t* matrix, int vertex_count)
{
	int i, j;
	for(i = 0; i < vertex_count; i++)
	{
		for(j = 0; j < vertex_count; j++)
		{
			long val = *(matrix + ((vertex_count*i)+j));
			if(val == NO_EDGE)
			{
				printf("-");
			}
			else
			{
				printf("%ld", val);
			}
			if(j < vertex_count -1)
			{
				printf(", ");
			}
		}
		printf("\n");
	}
}

void display_dbl_tiled_matrix(edge_int_t* matrix, int vertex_count)
{
	entry_pos_t next_pos;
	next_pos.r = 0;
	next_pos.c = 0;
	int i, j;
	
	for(i = 0; i < vertex_count; i++)
	{
		for(j = 0; j < vertex_count; j++)
		{
			/*
			int pos = ((i*vertex_count)+j);
			next_pos = compute_dbl_tile_pos(pos, next_pos, vertex_count);
			
			edge_int_t val = *(matrix+((next_pos.r*vertex_count)+next_pos.c));
			*/

			int bI = i/32;
			int bJ = j/32;
			int sI = i%32;
			int sJ = j%32;
			int bigCorner = bJ*32*32 + bI*32*vertex_count;
			int iI = sI/4;
			int iJ = sJ/4;
			int remI = sI%4;
			int remJ = sJ%4;
			int smallCorner = iJ*16 + iI*4*32;
			int rem = remJ + remI*4;
			int totalIndex = bigCorner + smallCorner + rem;
			edge_int_t val = *(matrix + totalIndex);

			if(val == NO_EDGE)
			{
				printf("-");
			}
			else
			{
				printf("%d", val);
			}
			if(j < vertex_count -1)
			{
				printf(", ");
			}
		}
		printf("\n");
	}
}


void test_matrix_result(edge_int_t* test_matrix, edge_int_t* inc_matrix, int vertex_count)
{
		int failed = 0;
		long pos;
		for(pos = 0; pos < ((long)vertex_count*(long)vertex_count); pos++)
		{
			if(!(*(test_matrix + pos) == *(inc_matrix + pos)))
			{
				failed = 1;
				break;
			}
		}
		if(failed) printf("failed\n");
		else printf("passed\n");
}


void test_dbl_tiled_result(edge_int_t* test_matrix, edge_int_t* inc_matrix, int vertex_count)
{
	entry_pos_t next_pos;
	next_pos.r = 0;
	next_pos.c = 0;

	int failed = 0;
	long pos;
	for(pos = 0; pos < (vertex_count*vertex_count); pos++)
	{
		//next_pos = compute_dbl_tile_pos(pos, next_pos, vertex_count);
		//edge_int_t val = *(inc_matrix+((next_pos.r*vertex_count)+next_pos.c));
		int blNum = pos / 1024;
		int blRem = pos % 1024;
		int bRow = blNum / (vertex_count / 32);
		int bCol = blNum % (vertex_count / 32);
		int sbNum = blRem / 16;
		int sbRem = blRem % 16;
		int sRow = sbNum / 8;
		int sCol = sbNum % 8;
		int remRow = sbRem / 4;
		int remCol = sbRem % 4;
		int totalRow = bRow * 32 + sRow * 4 + remRow;
		int totalCol = bCol * 32 + sCol * 4 + remCol;
		int totalIndex = totalRow * vertex_count + totalCol;
		if(*(inc_matrix + pos) != *(test_matrix + totalIndex))
		{
			failed = 1;
			break;
		}
	}
	if(failed) printf("failed\n");
	else printf("passed\n");
}

void warshall_empty(edge_int_t* matrix, int vertex_count)
{
}


int main(int argc, char** argv)
{
	int matrix_changed = 0;
	int v_set = 0;
	char* v_arg = NULL;
	int d_set = 0;
	char* d_arg = NULL;
	int i_set = 0;
	char* i_arg = NULL;
	int m_set = 0;
	char* m_arg = NULL;
	
	int test = 0;
	int display = 0;
	int c;
	int vertex_count;
	int avg_vertex_degree;
	int maximum_edge_weight;
	clock_t start;
	char* impl_name;
	
	void (*warshall_impl)(edge_int_t* , int) = NULL;
	void (*disp)(edge_int_t* , int) = NULL;
	void (*test_result)(edge_int_t*, edge_int_t*,int) = NULL;

	while ((c = getopt (argc, argv, "tpm:v:d:i:")) != -1)
	{
		switch (c)
		{
			case 'v':
				v_set = 1;
				v_arg = optarg;
				break;
			case 'd':
				d_set = 1;
				d_arg = optarg;
				break;
			case 'i':
				i_set = 1;
				i_arg = optarg;
				break;
			case 'm':
				m_set = 1;
				m_arg = optarg;
				break;
			case 'p':
				display = 1;
				break;
			case 't':
				test = 1;
				break;
			case '?':
				if (optopt == 'v' || optopt == 'd' || optopt == 'i' || optopt == 'm')
					fprintf (stderr, "Option -%c requires an argument.\n", optopt);
				else if (isprint (optopt))
					fprintf (stderr, "Unknown option `-%c'.\n", optopt);
				else
					fprintf (stderr,
									"Unknown option character `\\x%x'.\n",
									optopt);
				return 1;
			default:
				abort ();
		}
	}
	
	if(v_set == 0)
	{
		//printf("Must provide argument: -v <# of vertices>\n");
		//exit(1);
		vertex_count = DEFAULT_VERTEX_COUNT;
	}
	else
	{
		vertex_count = strtol(v_arg, NULL, 10);
/*
		int i;
		int p = strtol(v_arg, NULL, 10);
		if(p > 20)
		{
			fprintf(stderr, "The maximum value for argument '-v' is 20, i.e. 2^20 vertices.\n");
			exit(1);
		}		
		vertex_count = 1;
		for(i = 0; i < p; i++)
		{
			vertex_count <<= 1;
		}
*/	}		
	if(d_set == 0)
	{
		//printf("Must provide argument: -d <expected degree of each vertex>\n");
		//exit(1);
		avg_vertex_degree = DEFAULT_VERTEX_DEGREE;
	}
	else
	{
		avg_vertex_degree = strtol(d_arg, NULL, 10);
	}
	
	if(m_set == 0)
	{
		//printf("Must provide argument: -m <maximum edge weight>\n");
		//exit(1);
		maximum_edge_weight = DEFAULT_MAX_EDGE_WEIGHT;
	}
	else
	{
		maximum_edge_weight = strtol(m_arg, NULL, 10);
	}		
	
	if(i_set == 0)
	{
		// more implementations to come!
		printf("Must provide argument: -i {STANDARD|TILED|CUDA_STANDARD|THREADED_STANDARD|CUDA_TILED|CUDA_DBL_TILED|KATZ_KIDER}\n");
		exit(1);
	}

	edge_int_t* inc_matrix = (edge_int_t*)malloc(sizeof(edge_int_t)*vertex_count*vertex_count);
	edge_int_t* orig_matrix = inc_matrix;
	populate_matrix(inc_matrix, vertex_count, vertex_count/avg_vertex_degree, maximum_edge_weight);

	if(display)
	{
		printf("Original:\n");
		display_matrix(orig_matrix, vertex_count);
		printf("\n");
	}


	int i,j;
	edge_int_t *test_matrix = (edge_int_t*)malloc(sizeof(edge_int_t)*vertex_count*vertex_count);
	if(test)
	{
		for(i = 0; i < vertex_count; i++)
			for(j = 0; j < vertex_count; j++)
				*(test_matrix + ((vertex_count*i)+j)) = *(inc_matrix + ((vertex_count*i)+j));
		cuda_warshall_dbl_tiled(test_matrix, 1024);

		if(display)
		{
			printf("Standard:\n");
			display_matrix(test_matrix, vertex_count);
			printf("\n");
		}
	}


	if(strcmp(i_arg, "STANDARD") == 0)
	{
		test_result = test_matrix_result;
		disp = display_matrix;
		warshall_impl = warshall_standard;
		impl_name = "STANDARD";
	}
	else if(strcmp(i_arg, "TILED") == 0)
	{
		test_result = test_matrix_result;
		disp = display_matrix;
		warshall_impl = warshall_tiled;
		impl_name = "TILED";
	}
	else if(strcmp(i_arg, "CUDA_STANDARD") == 0)
	{
		test_result = test_matrix_result;
		disp = display_matrix;
		warshall_impl = cuda_warshall_standard;
		impl_name = "CUDA_STANDARD";
	}
	else if(strcmp(i_arg, "THREADED_STANDARD") == 0)
	{
		test_result = test_matrix_result;
		disp = display_matrix;
		warshall_impl = threaded_warshall_standard;
		impl_name = "THREADED_STANDARD";
	}
	else if(strcmp(i_arg, "CUDA_TILED") == 0)
	{
		test_result = test_matrix_result;
		disp = display_matrix;
		warshall_impl = cuda_warshall_tiled;
		impl_name = "CUDA_TILED";
	}
	else if(strcmp(i_arg, "CUDA_DBL_TILED") == 0)
	{
		test_result = test_dbl_tiled_result;
		disp = display_dbl_tiled_matrix;
		matrix_changed = 1;
		inc_matrix = (edge_int_t*)malloc(sizeof(edge_int_t)*vertex_count*vertex_count);
		dbl_tile_matrix(orig_matrix, inc_matrix, vertex_count);
		//display_matrix(inc_matrix, vertex_count);
		//display_dbl_tiled_matrix(inc_matrix, vertex_count);
		warshall_impl = cuda_warshall_dbl_tiled;
		impl_name = "CUDA_DBL_TILED";
		free(orig_matrix);
	}
	else if(strcmp(i_arg, "KATZ_KIDER") == 0)
	{
		test_result = test_matrix_result;
		disp = display_matrix;
		warshall_impl = cuda_katz_kider;
		impl_name = "KATZ_KIDER";
	}		
	else
	{
		printf("Unknown implementation: '%s'\n", i_arg);
		exit(1);
	}

	struct timespec tod_start;
	struct timespec tod_end;

	clock_gettime(CLOCK_REALTIME, &tod_start);
	start = clock();
	warshall_impl(inc_matrix, vertex_count);
	clock_gettime(CLOCK_REALTIME, &tod_end);
	double  r_time = (tod_end.tv_sec + tod_end.tv_nsec/((double)1000000000.0)) - (tod_start.tv_sec + tod_start.tv_nsec/((double)1000000000.0));
	printf("Implementation: %s\nVertices: %d\nAvg. Vertex Degree: %d\nMax. Edge Weight: %d\nCPU Time: %f\nElapsed Time: %f\n", 
			impl_name, vertex_count, avg_vertex_degree, maximum_edge_weight,((float)(clock()-start))/CLOCKS_PER_SEC, r_time );


	if(display)
	{
		printf("After:\n");
		disp(inc_matrix, vertex_count);
		printf("\n");
	}
	
	if(test)
	{
		test_result(test_matrix, inc_matrix, vertex_count);
	}

	free(inc_matrix);
	/*if(matrix_changed)
	{
		free(orig_matrix);
	}*/		
	return 0;
}
